
from pathlib import Path
import argparse
import json

import pandas as pd


def is_seoul_sig(sig):
    s = str(sig).strip()
    return s.startswith("11")


def build_hourly_weights_seoul(data_dir,
                               pattern = "data_202003_*h.csv")
    data_path = Path(data_dir)
    weights_by_hour: dict[int, dict[int, dict[int, float]]] = {}

    for path in sorted(data_path.glob(pattern)):
        # Extract hour from filename, e.g. data_202003_06h.csv -> 6
        hour_str = path.stem.split("_")[-1].replace("h", "")
        hour = int(hour_str)

        df = pd.read_csv(path)

        # Keep only rows where both origin & destination are Seoul SIGs
        # The file with the replaced names decided to look a bit weird so
        # I used generative models to try and discern which cols are the
        # correct ones and to give me strings I could put in for it to work.
        mask_seoul = (
            df["출발 시군구 코드"].astype(str).str.startswith("11")
            & df["도착 시군구 코드"].astype(str).str.startswith("11")
        )
        df = df[mask_seoul].copy()

        if df.empty:
            weights_by_hour[hour] = {}
            continue

        # Clean of the column -
        # remove * etc,
        # convert to numeric (errors -> NaN -> 0.0)
        move = pd.to_numeric(
            df["이동인구(합)"].astype(str).str.replace("*", "", regex=False),
            errors="coerce",
        ).fillna(0.0)

        df = df.assign(이동인구_num=move)

        # Aggregate per OD pair
        grouped = (
            df.groupby(["출발 시군구 코드", "도착 시군구 코드"])["이동인구_num"]
              .sum()
        )

        hour_weights: dict[int, dict[int, float]] = {}
        for (sig_out, sig_in), w in grouped.items():
            sig_out = int(sig_out)
            sig_in = int(sig_in)
            w = float(w)

            if sig_out not in hour_weights:
                hour_weights[sig_out] = {}
            hour_weights[sig_out][sig_in] = w/31

        weights_by_hour[hour] = hour_weights

    return weights_by_hour


def main():
    parser = argparse.ArgumentParser(
        description="Build hourly Seoul-only OD weight dicts from CSV files."
    )
    parser.add_argument(
        "data_dir",
        help="Directory containing data_202003_??h.csv files",
    )
    parser.add_argument(
        "-o",
        "--output",
        help="Optional path to save weights as JSON "
             "(keys: hour -> sig_out -> sig_in -> weight).",
    )

    args = parser.parse_args()

    weights = build_hourly_weights_seoul(args.data_dir)

    print("Hours processed:", sorted(weights.keys()))

    if args.output:
        json_ready = {
            str(h): {
                str(o): {str(d): w for d, w in dests.items()}
                for o, dests in weights[h].items()
            }
            for h in weights
        }
        with open(args.output, "w", encoding="utf-8") as f:
            json.dump(json_ready, f, ensure_ascii=False, indent=2)
        print(f"\nSaved weights to {args.output}")


if __name__ == "__main__":
    main()

